import heapq

graph = {
    'A': [('B', 11), ('D', 7), ('C', 14)],
    'B': [('E', 15)],
    'D': [('F', 25)],
    'C': [('F', 10)],
    'E': [('C', 8), ('H', 9)],
    'F': [('G', 20)],
    'H': [('G', 10)],
    'G': []
}


def ucs(start, goal):
    queue = [(0, start, [start])]
    visited = set()

    while queue:
        cost, node, path = heapq.heappop(queue)

        if node in visited:
            continue

        visited.add(node)

        print("Visited Node:", node, "Cost:", cost)

        if node == goal:
            return path, cost

        for child, w in graph[node]:
            if child not in visited:
                heapq.heappush(
                    queue,
                    (cost + w, child, path + [child])
                )

    return [], 0


path, cost = ucs('A', 'G')

print("Final Path:", path)
print("Total Cost:", cost)